default gold = 0
default loot = 0
default interest = 0
default wins = 0


init python:
    from math import ceil


label win:

    $ levels.end()

    if wins + 1 == len(levels.levels):
        jump end

    play music "music/theme3.ogg" volume 0.7

    hide screen player_end_turn

    hide screen enemy_stats0
    hide screen enemy_stats1
    hide screen enemy_stats2
    hide screen enemy_stats3

    show screen player_gold

    pause 1

    show ryohei seated smile with dissolve

    ryohei "You survived the trial."

    $ wins += 1
    $ interest = ceil(gold * 0.4)
    $ loot = wins + 2
    $ gold += loot + interest

    play audio "sound/gold.ogg"

    "You earned [loot] + [interest] (interest) gold."

    if wins == 1:
        call reward_card(
            Card(action={"attack": {"value": 1, "blood": True}}, cost=2, image="knife", name="Blood Blade"),
            "{i}Blood Blade{/i} deals extra damage based on your missing health."
        )

    elif wins == 2:
        call reward_card(
            Card(action={"attack": {"value": 3, "stun": True}}, cost=1, image="knife", name="Blunt Blade", uses=3),
            "{i}Blunt Blade{/i} stuns the enemy, but can only be used 3 times."
        )

    elif wins == 3:
        call reward_card(
            Card(action={"attack": {"value": 3, "comfrey": True}}, cost=1, image="knife", name="Light Blade", uses=3),
            "{i}Light Blade{/i} creates a single-use healing card ({i}Comfrey{/i})."
        )

    elif wins == 4:
        call reward_card(
            Card(action={"attack": {"value": 3, "all": True}}, cost=2, image="knife", name="Multi Blade", uses=3),
            "{i}Multi Blade{/i} damages all enemies, but can only be used 3 times."
        )

    if wins % 2 == 1:
        jump reward

    jump shop


label reward_card(card, dialogue):

    show screen card(card)

    ryohei "[dialogue]"

    menu:
        "Add this card to your deck?"

        "Yes":
            $ deck.cards.append(card)
            play audio "sound/draw.ogg"

        "No (+[max(wins, 6)] gold)
        {tooltip}Sell card and earn gold":
            $ gold += max(wins, 6)
            play audio "sound/gold.ogg"

    hide screen card

    return
