label lose:

    $ levels.end()

    hide screen player_end_turn
    hide screen player_stats
    hide screen player_gold

    hide screen enemy_stats0
    hide screen enemy_stats1
    hide screen enemy_stats2
    hide screen enemy_stats3

    ryohei "Your sacrifice was inevitable...{w=.3} Your blood will feed the entities."

    scene black onlayer enemies with Dissolve(1)

    "Wins: [wins]"

    return
