label shop:

    python:
        config.menu_include_disabled = True
        cost_base = max(wins, 3)
        cost_upgrade_stat = cost_base + player.stats_upgraded
        cost_card_buy = cost_base + player.cards_bought
        cost_card_upgrade = cost_base + player.cards_upgraded
        cost_card_remove = cost_base + player.cards_removed

    menu:
        "What do you want to do?"

        "Buy a card (-[cost_card_buy] gold)
        {tooltip}Add 1 card to your deck ([player.shop_cards] choices, nonrefundable)" if gold >= cost_card_buy:
            python:
                config.menu_include_disabled = False
                gold -= cost_card_buy
                player.cards_bought += 1
                cards = Card.generate(player.shop_cards)

            play audio "sound/gold.ogg"
            call screen card_add(cards)

        "Upgrade a card (-[cost_card_upgrade] gold)
        {tooltip}Upgrade 1 card in your deck ([player.shop_cards] choices, nonrefundable)" if gold >= cost_card_upgrade:
            python:
                config.menu_include_disabled = False
                gold -= cost_card_upgrade
                player.cards_upgraded += 1

                card_type = renpy.random.choice(
                    ["all"] * (1 if wins > 3 else 0) +
                    ["attack"] * 6 +
                    ["cost"] * (1 if wins > 3 else 0) +
                    ["draw"] * 3 +
                    ["energy"] * (1 if wins > 3 else 0) +
                    ["heal"] * 6 +
                    ["stun"] * (1 if wins > 2 else 0) +
                    ["times"] * (1 if wins > 3 else 0) +
                    []
                )

                if card_type in ["attack", "heal"]:
                    card_value = renpy.random.randint(1, 3)
                elif card_type in ["draw", "energy"]:
                    card_value = renpy.random.randint(1, 2)
                else:
                    card_value = 1

                cards = deck.get_cards(player.shop_cards, card_type)

            play audio "sound/gold.ogg"
            call screen card_upgrade(cards, card_type, card_value)

        "Remove a card (-[cost_card_remove] gold)
        {tooltip}Remove 1 card from your deck (nonrefundable)" if gold >= cost_card_remove:
            python:
                config.menu_include_disabled = False
                gold -= cost_card_remove
                player.cards_removed += 1

            play audio "sound/gold.ogg"
            call screen card_remove

        "Upgrade a stat (-[cost_upgrade_stat] gold)
        {tooltip}Upgrade a stat like max health (nonrefundable)" if gold >= cost_upgrade_stat:
            python:
                config.menu_include_disabled = False
                gold -= cost_upgrade_stat
                player.stats_upgraded += 1

            play audio "sound/gold.ogg"
            jump reward

        "Battle":
            python:
                config.menu_include_disabled = False
                levels.next()

            hide screen player_deck

            hide ryohei with Dissolve(1)

            jump battle


screen card_add(cards):

    frame:
        modal True
        padding (50, 50)
        xalign 0.5 yalign 0.5
        has vbox

        text "{size=36}Add 1 card to your deck:"

        null height 25

        hbox:
            spacing 25

            for card in cards:
                button:
                    action [
                        Queue(MUSIC_CHANNEL_UI, "sound/draw.ogg"),
                        Function(deck.cards.append, card),
                        Jump("shop"),
                    ]
                    hover_background colors.white
                    use card_frame(card)

        null height 25
        use shop_return


screen card_upgrade(cards, card_type, card_value):

    frame:
        modal True
        padding (50, 50)
        xalign 0.5 yalign 0.5
        has vbox

        text Card.label_upgrade(card_type, card_value)

        null height 25

        hbox:
            spacing 25

            for card in cards:
                button:
                    action [
                        Queue(MUSIC_CHANNEL_UI, "sound/draw.ogg"),
                        Function(card.upgrade, card_type, card_value),
                        Jump("shop"),
                    ]
                    hover_background colors.white
                    use card_frame(card)

        null height 25
        use shop_return


screen card_remove():

    frame:
        modal True
        padding (50, 50)
        xalign 0.5 yalign 0.5
        has vbox

        viewport:
            scrollbars "horizontal"
            ysize 450

            hbox:
                spacing 25

                for card in deck.cards:
                    button:
                        action [
                            Queue(MUSIC_CHANNEL_UI, "sound/draw.ogg"),
                            Function(deck.cards.remove, card),
                            Jump("shop"),
                        ]
                        hover_background colors.white
                        use card_frame(card)

        null height 50
        use shop_return


screen shop_return():

    frame:
        xalign 0.5
        textbutton "Skip":
            action Jump("shop")
